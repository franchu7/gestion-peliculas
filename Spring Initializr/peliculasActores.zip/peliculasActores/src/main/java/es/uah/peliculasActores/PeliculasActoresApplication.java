package es.uah.peliculasActores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeliculasActoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeliculasActoresApplication.class, args);
	}

}
